﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T01._Define_a_Class_Person
{
    class DateModifier
    {


        public static int DateCalculation(string d1, string d2)
        {

            DateTime first = DateTime.Parse(d1);
            DateTime second = DateTime.Parse(d2);

            int result = (int)Math.Abs((first - second).TotalDays);


            return result;
        }
    }
}
