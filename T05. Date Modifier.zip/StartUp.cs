﻿using System;
using System.Collections.Generic;
using System.Linq;
using T01._Define_a_Class_Person;


namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            string past = Console.ReadLine();
            string future = Console.ReadLine();

            int result = DateModifier.DateCalculation(past, future);

            Console.WriteLine(Math.Abs(result));
        }
    }
}
