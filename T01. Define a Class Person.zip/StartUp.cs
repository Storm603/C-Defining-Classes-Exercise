﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            Person human1 = new Person();
            human1.Name = "Peter";
            human1.Age = 20;

            Person human2 = new Person("George", 18);
            Person human3 = new Person("Jose", 43);


        }
    }
}
