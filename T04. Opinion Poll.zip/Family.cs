﻿using System;
using System.Collections.Generic;
using System.Text;
using DefiningClasses;

namespace T01._Define_a_Class_Person
{
    public class Family
    {
        public static List<Person> People { get; set; }

        public Family()
        {
            People = new List<Person>();
        }
        public void AddMember(Person member)
        {
            People.Add(member);
        }

        public Person GetOldestMember()
        {
            int oldestMember = int.MinValue;
            Person oldest = null;

            foreach (Person person in People)
            {
                if (person.Age > oldestMember)
                {
                    oldestMember = person.Age;
                    oldest = person;
                }
            }

            return oldest;
        }
    }


}
