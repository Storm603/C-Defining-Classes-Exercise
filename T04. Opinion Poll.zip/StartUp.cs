﻿using System;
using System.Collections.Generic;
using System.Linq;
using T01._Define_a_Class_Person;


namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Person> peoplesList = new List<Person>();

            int peopleToAdd = int.Parse(Console.ReadLine());

            Family create = new Family();

            for (int i = 0; i < peopleToAdd; i++)
            {
                string[] input = Console.ReadLine().Split();

                string name = input[0];
                int age = int.Parse(input[1]);

                Person human = new Person(name, age);
                peoplesList.Add(human);
                //create.AddMember(human);
            }

            peoplesList = peoplesList.OrderBy(x => x.Name).ToList();

            foreach (Person person in peoplesList)
            {
                if (person.Age > 30)
                {
                    Console.WriteLine($"{person.Name} - {person.Age}");
                }
            }

            //Person oldest = create.GetOldestMember();

            //Console.WriteLine($"{oldest.Name} {oldest.Age}");
        }
    }
}
