﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<Car> collection = new List<Car>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split();

                string model = input[0];
                double fuelAmount = double.Parse(input[1]);
                double fuelConsumptionPerKm = double.Parse(input[2]);

                Car car = new Car(model, fuelAmount, fuelConsumptionPerKm, 0);
                collection.Add(car);
            }

            string action = Console.ReadLine();

            while (action != "End")
            {
                string[] input = action.Split();


                string model = input[1];
                double amountOfKms = double.Parse(input[2]);

                foreach (Car car in collection)
                {
                    if (car.Model == model)
                    {
                        car.CanDrive(amountOfKms);
                    }
                }
                action = Console.ReadLine();
            }

            foreach (Car car in collection)
            {
                Console.WriteLine($"{car.Model} {car.FuelAmount:f2} {car.TravelledDistance}");
            }
        }
    }
}
